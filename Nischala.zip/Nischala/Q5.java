import java.util.*;

public class Q5
{
	public static void main(String[] args)
	{
		try
		{	
			Scanner s=new Scanner(System.in);
			System.out.println("Enter value:");
			int n=s.nextInt();
			int res=0;		
			res=10/n;
			System.out.println("result is:"+res);
		}
		catch(ArithmeticException | InputMismatchException a )
		{	
			System.out.println(a.getMessage());
		}
	}
}
